package sample;

public class Const {
    public static final String USER_TABLE = "tblUsers";
    public static final String USER_ID = "idusers";
    public static final String USER_FIRSTNAME = "FirstName";
    public static final String USER_LASTENAME = "LastName";
    public static final String USER_USERNAME = "Username";
    public static final String USER_PASSWORD = "Password";
}